
require('@openzeppelin/hardhat-upgrades');
const { ethers, upgrades } = require("hardhat");

async function main() {
  const EscrowV2 = await ethers.getContractFactory("Escrow");

  const escrowV2 = await upgrades.upgradeProxy(EscrowV2,[]);
  console.log("Beacon upgrade on:", escrowV2.address);
}

main();